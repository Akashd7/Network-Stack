=== Konte ===

Contributors: automattic
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready

Requires at least: 4.0
Tested up to: 5.2.2
Stable tag: 1.5.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Konte is a fully responsive Premium WordPress Theme with a pixel perfect design and extensive functionality.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= Version 1.5.0 =
* New - Support and include plugin YellowPencil to this theme. Plugin file is included in the theme package.
* New - Add new options to control product badges background color
* Update - Update plugins.
* Update - Update WooCommerce templates to version 3.7.0.
* Enhancement - Allows WPML to translate quick search links.
* Enhancement - Now can use ESC key to close modals, panels.
* Fix - Ajax add to cart on single product page doesn't trigger the event "added_to_cart" sometimes.
* Fix - Responsive issues of Instagram feed.
* Fix - Responsive issues of the mobile menu.
* Fix - Typography settings for product not working.
* Fix - Quick search issue when only one product returns.
* Fix - Wishlist counter calculates incorrectly when a product is removed from the wishlist.
* Fix - Incorrect related products on product layout v7.
* Fix - Error message with WP CLI.

= Version 1.4.1 =
* New - New option for the "Go to top" button at the footer.
* Fix - Instagram feed issue.

= Version 1.4.0 =
* Update - Update plugins.
* New - Add a new option to display product buttons on mobile.
* New - Support SoundCloud icon in the Social Menu.
* New - Support sharing via WhatsApp.
* Fix - Layout issue of product review form on mobile.
* Fix - Typography setting for widget title doesn't work.
* Fix - Incorrect products in side products section of product layout v7.
* Fix - Filter widget doesn't show up.
* Fix - Shop notification never disappear.
* Fix - Incorrect footer layout at 404 page.
* Fix - Warning of Instagram feed at footer.
* Fix - Issue of ajax add to cart on single product page.

= Version 1.3.2 =
* Improve - Security improvements.

= Version 1.3.1 =
* New - Add new option to turn product quick-view.
* Improve - Update RTL.
* Improve - Preview popup in Customizer.
* Improve - Preview preloader in Customizer.
* Fix - Instagram feed alignment issue.
* Fix - Typography settings for menu doesn't work with header v8 & v9.
* Fix - Responsiveness issues.
* Fix - Issue of normaly sticky header.

= Version 1.3.0 =
* New - Add "Size Guide" to the theme.
* Improve - Support purchase button for external products on wishlist.
* Fix - Error message when installing/upgrading WooCommerce plugin.
* Fix - Duplicated custom cart icon image.
* Fix - Social sharing icons are not clickable on mobile.
* Fix - Remove title attributes from SVG icons.
* Fix - SVG logo displays incorrectly.
* Fix - Layout issue of product layout v1.
* Fix - Always display "Sold Out" badge on variable products.
* Fix - Sometimes Instagram photos are not displayed.
* Fix - Product gallery issue on mobile with product layout v2 and v5.
* Fix - Incorrect style for product tabs element.
* Fix - Product Grid and Product Carousel elements cannot get featured products.

= Version 1.2.1 =
* Update - Update WooCommerce template files. Supports WooCommerce 3.6.x.
* Fix - Fix incorrect product category layout.
* Fix - Fix bug of product name on mini cart.
* Fix - Remove warning of Instagram footer photos feed on footer.
* Fix - Fix error with PHP 5.4

= Version 1.2.0 =
* New - Add new layout for the checkout page with 2 columns.
* New - Add campaign bar bellow the header.
* Update - Update plugins.
* Update - Update "Banner Imaeg" shortcode.

= Version 1.1.0 =
* New - Add Portfolio support
* New - Add new options to control product toolbar
* Update - Update WPML configuration file.
* Fix - Transparent header issue on Flex Posts template
* Fix - Transparent header issue on product page

= Version 1.0.2 =
* Fix - CSS issue of MailChimp checkbox.
* Fix - Responsiveness issues of Maintenance mode pages.
* Fix - Social share links don't work.

= Version 1.0.1 =
* Fix - error of custom color scheme
* Fix - CSS and responsiveness issues

= Version 1.0 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
