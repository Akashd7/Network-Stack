<?php
/**
 * General template hooks.
 *
 * @package Konte
 */

/**
 * Class of general template.
 */
class Konte_WooCommerce_Template {
	/**
	 * Initialize.
	 */
	public static function init() {
		// Disable the default WooCommerce stylesheet.
		add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts' ), 20 );

		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );

		// Change the site content container.
		add_filter( 'konte_content_container_class', array( __CLASS__, 'content_container_class' ), 20 );

		// Remove default WooCommerce wrapper.
		remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
		remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
		add_action( 'woocommerce_before_main_content', array( __CLASS__, 'wrapper_before' ) );
		add_action( 'woocommerce_after_main_content', array( __CLASS__, 'wrapper_after' ) );

		// Change the markup of sale flash.
		add_filter( 'woocommerce_sale_flash', array( __CLASS__, 'sale_flash' ), 10, 3 );

		// Change star rating HTML.
		add_filter( 'woocommerce_get_star_rating_html', array( __CLASS__, 'star_rating_html' ), 10, 3 );

		// Change price order.
		add_filter( 'woocommerce_format_sale_price', array( __CLASS__, 'sale_price_html' ), 10, 3 );

		// Edit add to wishlist button.
		add_filter( 'soo_wishlist_button', array( __CLASS__, 'wishlist_button' ), 10, 2 );

		// Edit breadcrum.
		add_filter( 'woocommerce_breadcrumb_defaults', array( __CLASS__, 'breadcrumb_args' ) );

		// Update counter via ajax.
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'cart_link_fragment' ) );
	}

	/**
	 * WooCommerce specific scripts & stylesheets.
	 *
	 * @return void
	 */
	public static function scripts() {
		if ( wp_style_is( 'select2', 'registered' ) ) {
			wp_enqueue_style( 'select2' );
		}

		wp_enqueue_style( 'konte-woocommerce', get_template_directory_uri() . '/woocommerce.css' );

		$css            = self::get_inline_style();
		$product_layout = konte_get_option( 'product_layout' );

		if ( $css ) {
			wp_add_inline_style( 'konte-woocommerce', $css );
		}

		if ( is_rtl() ) {
			wp_enqueue_style( 'konte-woocommerce-rtl', get_template_directory_uri() . '/woocommerce-rtl.css' );
		}

		wp_register_script( 'zoom', get_theme_file_uri( 'js/jquery.zoom.min.js' ), array( 'jquery' ), '1.7.18', true );
		wp_register_script( 'swiper', get_theme_file_uri( 'js/swiper.min.js' ), array( 'jquery' ), '4.3.2', true );
		wp_register_script( 'jquery-quantity-dropdown', get_theme_file_uri( 'js/quantity-dropdown.js' ), array( 'jquery' ), '1.0.0', true );
		wp_register_script( 'notify', get_theme_file_uri( 'js/notify.min.js' ), array( 'jquery' ), '0.4.2', true );

		if ( wp_script_is( 'flexslider', 'registered' ) ) {
			wp_enqueue_script( 'flexslider' );
		}

		if ( wp_script_is( 'select2', 'registered' ) ) {
			wp_enqueue_script( 'select2' );
		}

		if ( wp_script_is( 'wc-add-to-cart-variation', 'registered' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
		}

		if ( is_product() && in_array( $product_layout, array( 'v2', 'v5', 'v7' ) ) ) {
			wp_enqueue_script( 'sticky-kit' );
		}

		if ( 'zoom' == konte_get_option( 'shop_product_hover' ) ) {
			wp_enqueue_script( 'zoom' );
		}

		if ( 'masonry' == konte_get_option( 'shop_layout' ) ) {
			wp_enqueue_script( 'jquery-masonry' );
		}

		if ( is_product() || 'carousel' == konte_get_option( 'shop_layout' ) ) {
			wp_enqueue_script( 'swiper' );
		}

		if ( konte_get_option( 'product_added_to_cart_notice' ) || konte_get_option( 'product_added_to_wishlist_notice' ) ) {
			wp_enqueue_script( 'notify' );
		}

		wp_enqueue_script( 'jquery-quantity-dropdown' );
	}

	/**
	 * Get CSS code of settings for shop.
	 *
	 * @return string
	 */
	public static function get_inline_style() {
		$product_layout = konte_get_option( 'product_layout' );
		$header_height  = 0;
		$css            = '';

		// Typography
		$css .= self::typography_css();

		// Get header height.
		if (
			( is_product() && in_array( $product_layout, array( 'v1', 'v3', 'v5' ) ) )
			|| ( ( is_shop() || is_product_taxonomy() ) && 'standard' == konte_get_option( 'shop_page_header' ) )
		) {
			if ( 'prebuild' == konte_get_option( 'header_present' ) ) {
				$header_height = absint( konte_get_option( 'header_main_height' ) );

				if ( in_array( konte_get_option( 'header_version' ), array( 'v8', 'v9' ) ) ) {
					$header_height += absint( konte_get_option( 'header_bottom_height' ) );
				}
			} else {
				$header_main = array_filter( array(
					'left'   => konte_get_option( 'header_main_left' ),
					'center' => konte_get_option( 'header_main_center' ),
					'right'  => konte_get_option( 'header_main_right' ),
				) );

				if ( ! empty( $header_main ) ) {
					$header_height += absint( konte_get_option( 'header_main_height' ) );
				}

				$header_bottom = array_filter( array(
					'left'   => konte_get_option( 'header_bottom_left' ),
					'center' => konte_get_option( 'header_bottom_center' ),
					'right'  => konte_get_option( 'header_bottom_right' ),
				) );

				if ( ! empty( $header_bottom ) ) {
					$header_height += absint( konte_get_option( 'header_bottom_height' ) );
				}
			}
		}

		// Product.
		if ( is_product() && in_array( $product_layout, array( 'v1', 'v3', 'v5' ) ) ) {
			if ( $header_height ) {
				if ( 'v5' != $product_layout ) {
					$css .= 'div.product { padding-top: ' . $header_height . 'px; }';
				} else {
					$css .= 'div.product .summary { padding-top: ' . $header_height . 'px; }';
				}

				$css .= '.woocommerce div.product.layout-v1 .woocommerce-product-gallery { margin-top: -' . ( $header_height + 80 ) . 'px; }';
				$css .= '.woocommerce div.product.layout-v1 .woocommerce-badges { top: ' . ( $header_height + 80 ) . 'px; }';
				$css .= '.single-product.product-v3 .product-toolbar { top: ' . $header_height . 'px; }';

				$css .= '@media (max-width: 1199px) { .woocommerce div.product.layout-v1 .woocommerce-product-gallery { margin-top: 0; } }';
			}

			if ( $mobile_header_height = absint( konte_get_option( 'mobile_header_height' ) ) ) {
				$css .= '@media (max-width: 1199px) { .woocommerce div.product.layout-v1 .woocommerce-badges { top: ' . ( $mobile_header_height + 80 ) . 'px; } }';
				$css .= '@media (max-width: 991px) { .woocommerce div.product.layout-v1 .woocommerce-badges { top: ' . ( $mobile_header_height + 40 ) . 'px; } }';
				$css .= '@media (max-width: 767px) { .woocommerce div.product.layout-v1 .woocommerce-badges { top: ' . ( $mobile_header_height ) . 'px; } }';
				$css .= '.single-product.product-v3 .product-toolbar { top: ' . $mobile_header_height . 'px; }';
			}

			if ( 'v1' == $product_layout || 'v3' == $product_layout ) {
				$background = get_post_meta( get_the_ID(), 'background_color', true );

				if ( $background ) {
					$css .= '.woocommerce div.product { background-color: ' . esc_attr( $background ) . ' }';
				}
			}
		}

		// Page header.
		if ( ( is_shop() || is_product_taxonomy() ) ) {
			if ( 'standard' == konte_get_option( 'shop_page_header' ) ) {
				$page_header_height = konte_get_option( 'shop_page_header_height' );
				$page_header_image  = konte_get_option( 'shop_page_header_image' );
				$header_class       = apply_filters( 'konte_header_class', array() );

				if ( is_product_taxonomy() ) {
					$term_id  = get_queried_object_id();
					$image_id = absint( get_term_meta( $term_id, 'page_header_image_id', true ) );

					if ( $image_id ) {
						$image             = wp_get_attachment_image_src( $image_id, 'full' );
						$page_header_image = $image ? $image[0] : $page_header_image;
					}
				}

				$css .= '.woocommerce-products-header {
					height: ' . intval( $page_header_height ) . 'px;
					background-image: url(' . esc_url( $page_header_image ) . ');
					padding-top: ' . ( in_array( 'transparent', $header_class, true ) ? $header_height : 0 ) . 'px
				}';

				$css .= '@media (max-width: 767px) { .woocommerce-products-header {
					height: ' . ( intval( $page_header_height ) / 2 ) . 'px;
					padding-top: ' . ( in_array( 'transparent', $header_class, true ) ? intval( konte_get_option( 'mobile_header_height' ) ) : 0 ) . 'px
				} }';
			}
		}

		// Display settings for shop page.
		if ( is_shop() ) {
			$shop_page_id = wc_get_page_id( 'shop' );

			if ( 'custom' == get_post_meta( $shop_page_id, 'header_background', true ) ) {
				$background = get_post_meta( $shop_page_id, 'header_background_color', true );

				if ( $background ) {
					$css .= '.woocommerce .site-header.custom { background-color: ' . $background . '; }';
				}
			}

			if ( 'custom' == get_post_meta( $shop_page_id, 'footer_background', true ) ) {
				$background = get_post_meta( $shop_page_id, 'footer_background_color', true );

				if ( $background ) {
					$css .= '.woocommerce .site-footer.custom { background-color: ' . $background . '; }';
				}
			}

			if ( 'custom' == get_post_meta( $shop_page_id, 'top_spacing', true ) ) {
				$top_padding = get_post_meta( $shop_page_id, 'top_padding', true );
				$css         .= $top_padding ? '.site-content { padding-top: ' . esc_attr( $top_padding ) . ' !important; }' : '';
			}

			if ( 'custom' == get_post_meta( $shop_page_id, 'bottom_spacing', true ) ) {
				$bottom_padding = get_post_meta( $shop_page_id, 'bottom_padding', true );
				$css            .= $bottom_padding ? '.site-content { padding-bottom: ' . esc_attr( $bottom_padding ) . ' !important; }' : '';
			}

			// Product badges.
			if ( ( $color = konte_get_option( 'shop_badge_sale_bg' ) ) ) {
				$css .= '.woocommerce-badge.onsale {background-color: ' . $color . '}';
			}

			if ( ( $color = konte_get_option( 'shop_badge_new_bg' ) ) ) {
				$css .= '.woocommerce-badge.new {background-color: ' . $color . '}';
			}

			if ( ( $color = konte_get_option( 'shop_badge_featured_bg' ) ) ) {
				$css .= '.woocommerce-badge.featured {background-color: ' . $color . '}';
			}

			if ( ( $color = konte_get_option( 'shop_badge_soldout_bg' ) ) ) {
				$css .= '.woocommerce-badge.sold-out {background-color: ' . $color . '}';
			}

			// Custom page CSS of WPB.
			$shop_page_css           = get_post_meta( $shop_page_id, '_wpb_post_custom_css', true );
			$shop_page_shortcode_css = get_post_meta( $shop_page_id, '_wpb_shortcodes_custom_css', true );

			if ( ! empty( $shop_page_css ) ) {
				$css .= $shop_page_css;
			}

			if ( ! empty( $shop_page_shortcode_css ) ) {
				$css .= $shop_page_shortcode_css;
			}
		}

		return apply_filters( 'konte_woocommerce_inline_style', $css );
	}

	/**
	 * Get typography CSS base on settings
	 */
	protected static function typography_css() {
		$settings = array(
			'typo_product_title'         => '.woocommerce div.product .product_title',
			'typo_product_short_desc'    => '.woocommerce div.product .woocommerce-variation-description, .woocommerce div.product .woocommerce-product-details__short-description, .woocommerce .woocommerce-Tabs-panel--description',
			'typo_catalog_page_title'    => '.woocommerce-products-header .page-title',
			'typo_catalog_product_title' => 'ul.products li.product .woocommerce-loop-product__title a',
		);

		return konte_get_typography_css( $settings );
	}

	/**
	 * Add 'woocommerce-active' class to the body tag.
	 *
	 * @param  array $classes CSS classes applied to the body tag.
	 *
	 * @return array $classes modified to include 'woocommerce-active' class.
	 */
	public static function body_class( $classes ) {
		$classes[] = 'woocommerce-active';

		// Adds a class of product layout.
		if ( is_product() ) {
			$product_layout = konte_get_option( 'product_layout' );
			$classes[]      = 'product-' . $product_layout;

			if ( 'v3' == $product_layout ) {
				$classes[] = 'no-bottom-spacing';
			}
		}

		if ( is_account_page() && ! is_user_logged_in() ) {
			$classes[] = 'woocommerce-account-login';
		}

		if ( konte_is_order_tracking_page() ) {
			$classes[] = 'woocommerce-order-tracking';
		}

		if ( function_exists( 'soow_is_wishlist' ) && soow_is_wishlist() ) {
			$classes[] = 'woocommerce-wishlist';
		}

		if ( is_shop() || is_product_taxonomy() ) {
			$classes[] = 'woocommerce-archive';
			$classes[] = 'shop-layout-' . konte_get_option( 'shop_layout' );

			if ( 'carousel' != konte_get_option( 'shop_layout' ) ) {
				$classes[] = 'woocommerce-nav-' . konte_get_option( 'shop_nav' );
			}

			$shop_page_header = konte_get_option( 'shop_page_header' );

			if ( 'standard' == $shop_page_header ) {
				$classes[] = 'no-top-spacing';
			} elseif ( 'minimal' == $shop_page_header && 'fluid' == konte_get_option( 'shop_page_header_container' ) ) {
				$classes[] = 'woocommerce-header--minimal-fluid';
			}
		}

		if ( is_shop() ) {
			$shop_page_id = wc_get_page_id( 'shop' );

			if ( 'none' == get_post_meta( $shop_page_id, 'top_spacing', true ) || 'transparent' == get_post_meta( $shop_page_id, 'header_background', true ) ) {
				$classes[] = 'no-top-spacing';
			}

			if ( 'none' == get_post_meta( $shop_page_id, 'bottom_spacing', true ) || 'transparent' == get_post_meta( $shop_page_id, 'footer_background', true ) ) {
				$classes[] = 'no-bottom-spacing';
			}
		}

		if ( is_checkout() ) {
			$classes[] = 'woocommerce-checkout-' . konte_get_option( 'checkout_layout' );
		}

		if ( konte_get_option( 'mobile_shop_product_buttons' ) ) {
			$classes[] = 'mobile-shop-buttons';
		}

		return $classes;
	}

	/**
	 * Change the content container class for product and shop pages.
	 *
	 * @param string $class Container class.
	 *
	 * @return string
	 */
	public static function content_container_class( $class ) {
		if ( is_product() ) {
			$class = 'product-content-container konte-container';

			if ( 'v3' == konte_get_option( 'product_layout' ) ) {
				$class = 'product-content-container konte-container-fluid';
			}
		} elseif ( is_shop() || is_product_taxonomy() ) {
			$class = 'shop-content-container konte-container';
		}

		return $class;
	}

	/**
	 * Before Content.
	 * Wraps all WooCommerce content in wrappers which match the theme markup.
	 */
	public static function wrapper_before() {
		?>
		<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
		<?php
	}

	/**
	 * After Content.
	 * Closes the wrapping divs.
	 */
	public static function wrapper_after() {
		?>
		</main><!-- #main -->
		</div><!-- #primary -->
		<?php
	}

	/**
	 * Sale badge.
	 *
	 * @param string $output  The sale flash HTML.
	 * @param object $post    The post object.
	 * @param object $product The product object.
	 *
	 * @return string
	 */
	public static function sale_flash( $output, $post, $product ) {
		if ( ! konte_get_option( 'shop_badge_sale' ) ) {
			return '';
		}

		$type       = konte_get_option( 'shop_badge_sale_type' );
		$text       = konte_get_option( 'shop_badge_sale_text' );
		$percentage = 0;

		if ( 'percent' == $type || false !== strpos( $text, '{%}' ) ) {
			if ( $product->get_type() == 'variable' ) {
				$available_variations = $product->get_available_variations();
				$max_percentage       = 0;
				$total_variations     = count( $available_variations );

				for ( $i = 0; $i < $total_variations; $i++ ) {
					$variation_id        = $available_variations[ $i ]['variation_id'];
					$variable_product    = new WC_Product_Variation( $variation_id );
					$regular_price       = $variable_product->get_regular_price();
					$sales_price         = $variable_product->get_sale_price();
					$variable_percentage = $regular_price && $sales_price ? round( ( ( ( $regular_price - $sales_price ) / $regular_price ) * 100 ) ) : 0;

					if ( $variable_percentage > $max_percentage ) {
						$max_percentage = $variable_percentage;
					}
				}

				$percentage = $max_percentage ? $max_percentage : $percentage;
			} elseif ( $product->get_regular_price() != 0 ) {
				$percentage = round( ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100 );
			}
		}

		if ( 'percent' == $type ) {
			$output = '<span class="onsale woocommerce-badge"><span>' . $percentage . '%</span></span>';
		} else {
			$text = str_replace( '{%}', $percentage . '%', $text );
			$output = '<span class="onsale woocommerce-badge"><span>' . esc_html( $text ) . '</span></span>';
		}

		return $output;
	}

	/**
	 * Star rating HTML.
	 *
	 * @param string $html   Star rating HTML.
	 * @param int    $rating Rating value.
	 * @param int    $count  Rated count.
	 *
	 * @return string
	 */
	public static function star_rating_html( $html, $rating, $count ) {
		$html = '<span class="max-rating rating-stars">
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
				</span>';
		$html .= '<span class="user-rating rating-stars" style="width:' . ( ( $rating / 5 ) * 100 ) . '%">
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
					<span class="svg-icon star-icon"><svg><use xlink:href="#star"></use></svg></span>
				</span>';

		$html .= '<span class="screen-reader-text">';

		if ( 0 < $count ) {
			/* translators: 1: rating 2: rating count */
			$html .= sprintf( _n( 'Rated %1$s out of 5 based on %2$s customer rating', 'Rated %1$s out of 5 based on %2$s customer ratings', $count, 'konte' ), '<strong class="rating">' . esc_html( $rating ) . '</strong>', '<span class="rating">' . esc_html( $count ) . '</span>' );
		} else {
			/* translators: %s: rating */
			$html .= sprintf( esc_html__( 'Rated %s out of 5', 'konte' ), '<strong class="rating">' . esc_html( $rating ) . '</strong>' );
		}

		$html .= '</span>';

		return $html;
	}

	/**
	 * Change the order of onsale products' price.
	 *
	 * @param string $price         The price HTML.
	 * @param float  $regular_price The regular price.
	 * @param float  $sale_price    The sale price.
	 *
	 * @return string
	 */
	public static function sale_price_html( $price, $regular_price, $sale_price ) {
		$price = '<ins>' . ( is_numeric( $sale_price ) ? wc_price( $sale_price ) : $sale_price ) . '</ins> <del>' . ( is_numeric( $regular_price ) ? wc_price( $regular_price ) : $regular_price ) . '</del>';

		return $price;
	}

	/**
	 * Edit add to wihslist button.
	 *
	 * @param string $button The wishlist button HTML.
	 * @param array  $args   Wishlish button argurments.
	 *
	 * @return string
	 */
	public static function wishlist_button( $button, $args ) {
		$product_layout = konte_get_option( 'product_layout' );

		return sprintf(
			'<a href="%s" data-product_id="%s" data-product_type="%s" class="%s" rel="nofollow">
				<span class="add-to-wishlist add">
					%s
					<span class="screen-reader-text button-text">%s</span>
				</span>
				<span class="adding-to-wishlist adding">
					<span class="spinner"></span>
					<span class="screen-reader-text button-text">%s</span>
				</span>
				<span class="brow-wishlist added">
					%s
					<span class="screen-reader-text button-text">%s</span>
				</span>
			</a>',
			esc_url( $args['url'] ),
			esc_attr( $args['product_id'] ),
			esc_attr( $args['product_type'] ),
			esc_attr( implode( ' ', $args['classes'] ) ),
			konte_svg_icon( 'icon=heart-o&echo=0' ),
			'v4' == $product_layout ? esc_html__( 'Wishlist', 'konte' ) : esc_html__( 'Add to wishlist', 'konte' ),
			'v4' == $product_layout ? esc_html__( 'Wishlist', 'konte' ) : esc_html__( 'Adding to wishlist', 'konte' ),
			konte_svg_icon( 'icon=heart&echo=0' ),
			'v4' == $product_layout ? esc_html__( 'Wishlist', 'konte' ) : esc_html__( 'Added to wishlist', 'konte' )
		);
	}

	/**
	 * Changes breadcrumb args.
	 *
	 * @param array $args The breadcrumb argurments.
	 *
	 * @return array
	 */
	public static function breadcrumb_args( $args ) {
		$args['delimiter'] = konte_svg_icon( 'icon=arrow-breadcrumb&echo=0&class=delimiter' );

		return $args;
	}

	/**
	 * Cart Fragments.
	 *
	 * Ensure cart contents update when products are added to the cart via AJAX.
	 *
	 * @param array $fragments Fragments to refresh via AJAX.
	 *
	 * @return array Fragments to refresh via AJAX.
	 */
	public static function cart_link_fragment( $fragments ) {
		$fragments['span.cart-counter']       = '<span class="counter cart-counter">' . intval( WC()->cart->get_cart_contents_count() ) . '</span>';
		$fragments['span.cart-panel-counter'] = '<span class="cart-panel-counter">(' . intval( WC()->cart->get_cart_contents_count() ) . ')</span>';

		return $fragments;
	}
}
