<?php
/**
 * Hooks for nav menus
 */

function konte_page_menu_args( $args ) {
	$args['container']  = 'ul';
	$args['menu_class'] = 'menu nav-menu';
	$args['before']     = '';
	$args['after']      = '';

	return $args;
}

add_filter( 'wp_page_menu_args', 'konte_page_menu_args' );

/**
 * Add a walder object for all nav menu
 *
 * @since  1.0.0
 *
 * @param  array $args The default args
 *
 * @return array
 */
function konte_mega_menu_args( $args ) {
	// Only support mega menu if the Konte Addons plugin installed.
	if ( ! class_exists( 'Konte_Addons_Mega_Menu_Walker' ) ) {
		return $args;
	}

	if ( in_array( $args['theme_location'], array( 'primary', 'secondary' ) ) ) {
		// Not using mega menu for vertical menu.
		if ( 'prebuild' == konte_get_option( 'header_present' ) && 'v10' == konte_get_option( 'header_version' ) ) {
			return $args;
		}

		$args['fallback_cb'] = false;
		if ( 'mobile-menu__nav' != $args['container_class'] ) {
			$args['walker'] = new Konte_Addons_Mega_Menu_Walker;
		}
	}

	return $args;
}

add_filter( 'wp_nav_menu_args', 'konte_mega_menu_args' );
